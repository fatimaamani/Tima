Covid Module
==============

![screenshot](https://gitlab.com/francoisjacquet/Covid/raw/master/screenshot.png?inline=false)

http://gitlab.com/francoisjacquet/Covid

Version 2.3 - October, 2021

License GNU GPL v2

Author François Jacquet

DESCRIPTION
-----------
This module serves as an covid for developers who wish to create their own module for RosarioSIS.
You will find useful comments in each file.
Inline help.
Consult the [Starter Guide](https://gitlab.com/francoisjacquet/Covid/wikis/Starter-Guide)!

CONTENT
-------
Covid
- Covid Widget
- Setup

Resources
- Covid Resource

INSTALL
-------
Copy the `Covid/` folder (if named `Covid-master`, rename it) and its content inside the `modules/` folder of RosarioSIS.

Go to _School Setup > School Configuration > Modules_ and click "Activate".

Requires RosarioSIS 6.8+
