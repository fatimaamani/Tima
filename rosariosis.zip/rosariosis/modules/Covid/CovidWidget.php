<?php 
require_once 'ProgramFunctions/Fields.fnc.php';



$host="localhost";
$port="5432";
$dbname="rosariosis_db";
$user="";
$password="matifa";

$connection_string= "host={$host} port={$port} dbname={$dbname} user={$user} password={$password}";
$db = pg_connect($connection_string);


echo('<div  tabindex="0" role="main" class="mod">
				<table class="header widefat rt list">
					<tbody>
						<tr class="cv">
							<td class="header1"> 
								<h2> <span class="module-icon Covid"></span> CovidInfo</h2>
							</td>

						</tr>
					</tbody>
				</table><br>
				<table class="postbox cellspacing-0">


		
			<thead><tr><th class="center"><h3 class="title">Find&nbsp;People&nbsp;Information</h3></th></tr></thead>
			<tbody><tr><td class="popTable"><form name="search" id="search" action="Modules.php?modname=Covid/CovidWidget.php&amp;modfunc=&amp;search_modfunc=list&amp;next_modname=Covid/CovidWidget.php&amp;advanced=" method="GET">

			</div>');
	

// 	function staff() {

// 		$staffs=  DBGet( DBQuery("SELECT last_name from staff"));

// 		$j=1;
// 		//echo '<div style="margin-top:50px;>';
// 		echo('<label style="margin-left:100px;">Enseignants</label> <select>');
// 		while ($j<=count($staffs)){
// 			$staff=$staffs[$j];
			
// 			foreach ($staff as $last_name){
// 				echo '<option>' .$last_name."</option>";
// 			}
// 				$j=$j+1;
// 				echo $j;
// 		}	
// 	} 
// staff();
// echo('</select>&nbsp;&nbsp;');

/*function stu() {

		$studs=  DBGet( DBQuery("SELECT last_name from students"));

		$j=1;
		//echo '<div style="margin-top:50px;>';
		echo('<div ><label style="">Students: </label> <select type="text" name="nom">');
		while ($j<=count($studs)){
			$staff=$studs[$j];
			
			foreach ($staff as $last_name){
				echo '<option>' .$last_name."</option>";
			}
				$j=$j+1;
				echo $j;
		}	
	} 
	stu();
	echo('</select>');*/
	

	echo ('<form method="POST" action="Modules.php?modname=Covid/CovidWidget.php">
    <div>
	
	<label for="lname">Last name</label>
	<input type="text" id="lname" name="lname" size="24" maxlength="50" autofocus="" required><br><br>
	<label for="fname" >First name</label>
	<input type="text" id="fname" name="fname" size="24" maxlength="50" autofocus="" required><br>
	</div><br>
	

	

	<div style="
	border-radius: 3px;
	padding-left:80px;
	padding-right:80px;
	box-sizing: content-box;
	white-space: normal;
	border-color: #15556b;
	font-weight: 700;
	input[type="submit"],
	color: #fff;
	background: -moz-linear-gradient(top,#298cba,#1d6385);
	text-shadow: rgba(0,0,0,.3) 0 -1px 0;
	outline: 0;
	max-width: 100%;
	font-size: 14px;
	word-wrap: break-word;">
	<input class="button-primary" type="submit" name="envoyer" value="Chercher" />
    </div> 

    
    <div style="display:none;">
	<label for="role">Role:</label>
      <input type="radio" name="role" value="student" size="24" maxlength="50" autofocus="" checked>
	 <label for="student">student</label>&nbsp;&nbsp;&nbsp;
    </div><br><br>

    <div>
	<label for="etat">Etat Santé:</label>
      <input type="radio" onclick="displaySain()" name="etat" value="malade" size="24" maxlength="50" autofocus="">
	  <label for="etat">malade</label>&nbsp;&nbsp;&nbsp;
	  <input type="radio" name="etat" onclick="displayMalade()" value="sain"size="24" maxlength="50" autofocus="">
	  <label for="etat">sain</label>
    </div><br><br>

    <div id="MaladeBox">
    <div>
	<label for="date">Date Maladie</label>
      <input type="date" name="date" size="24" maxlength="50" autofocus="">
    </div><br>

     <div>
	<label for="periode">Période de Confinement:&nbsp;</label>
               <select type="text" name = "periodeConf">
               <option value=""></option>
                  <option value="1er jour"> 1er jour </option>
                  <option value="2e jour" >2e jours </option>
                  <option value="3e jour" >3e jour </option>
                  <option value="4e jour" >4e jour </option>
                </select><br><br>
    </div>
    
    <div>
	&nbsp;&nbsp;<label for="dateFin">Date fin Confinement</label>
      <input type="date" name="dateFin" size="24" maxlength="50" autofocus="" >
    </div><br><br>
    </div>
    


    <div id="SainBox">
    <div>
	
	<label for="type">Type Vaccin</label>
        <select type="text"name="type" id="type"> 
				<option value=""></option>
				<option value="Pfizer/BioNTech">Pfizer/BioNTech</option>
				<option value="Moderna">Moderna</option>
				<option value="AstraZeneca">AstraZeneca</option>
				<option value="Johnson & Johnson ">Johnson & Johnson </option>
				<option value="Spoutnik V">Spoutnik V</option>
				<option value="Sinovac">Sinovac</option>
	    </select>
    </div><br>

    <div>
	&nbsp;&nbsp;<label for="dose">Nombre de dose</label>
      <select name = "dose" type="number"> 
				<option value="0"></option>
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
	 </select>
    </div><br>
    <div>
	&nbsp;&nbsp;<label for="dateVac">Date Vaccination</label>
      <input type="date" name="dateVac">
    </div><br><br>
    </div>


	<div style="
	border-radius: 3px;padding-left:80px;
	 box-sizing: content-box;
	white-space: normal;
	border-color: #15556b;
	font-weight: 700;
	input[type="submit"],
	color: #fff;background: -moz-linear-gradient(top,#298cba,#1d6385);
	text-shadow: rgba(0,0,0,.3) 0 -1px 0;outline: 0;
	max-width: 100%;
	font-size: 14px;
	word-wrap: break-word;">

    <input class="button-primary" type="submit"  name="submit" size="24" maxlength="50" autofocus="" value="Enregistrer">
</div>
    </form>');

function add(){
	$nom = $_GET['lname'];
	$etat = $_GET['etat'];
	$date = $_GET['date'];
	$vaccin = $_GET['type'];
	$dose = $_GET['dose'];
	$role=$_GET['role'];
    $periodCon=$_GET['periodeConf'];
    $DateFin=$_GET['dateFin'];
	$firstname = $_GET['fname'];
    $DateVac=$_GET['dateVac'];

DBQuery( "INSERT INTO Covid ( lastname, status, sickness, vaccin, doses, role,periodeconfinement,datefinconfinement,datevac,firstname)  VALUES ('". $nom ."', '". $etat ."','". $date ."', '". $vaccin ."', '". $dose ."', '". $role ."' , '". $periodCon."', '". $DateFin."', '". $DateVac ."', '". $firstname ."' )" );
}
if (isset($_GET['submit'])) {
	add();
	//echo 'an shigo';
}

// function search(){
// 	$students=  DBGet( DBQuery("SELECT last_name from Students"));
// 	$i=1;
// 	while ($i<=count($students)){
// 		$student = $students[$i];
// 		foreach ($student as $eleve) {
// 			if ($_GET['nom']== $eleve ){
// 			echo $eleve;
// 			}
// 		}
// 		$i = $i+1;
// 	}
// }

function student (){
	$nom=$_GET['lname'];
 

	if ((isset($_REQUEST['students']['FIRST_NAME']) && empty($_REQUEST['students']['FIRST_NAME'])) || (isset($_REQUEST['students']['LAST_NAME']) && empty($_REQUEST['students']['LAST_NAME'])))
			$required_error = true;


 	$students=  DBGet( DBQuery("SELECT lastname,firstname,status,sickness,periodeconfinement,datefinconfinement,role from covid where lastname like '%$nom%' and role like '%student%' and status like '%malade%'"));

 	  $i=1;

  echo ('<div><table border="1" width="300px" cellspacing="0" cellpadding="6">
     <h3>Historique Infection</h3>
         <tr>
                 <th>lastname</th>
				 <th>firstname</th>
                 <th>status</th>
                 <th>sickness</th>
                 <th>periode de confinement</th>
                 <th>date fin confinement</th>
                 <th>role</th>
              </tr>  '); 

      while ($i<=count($students)){
  		$student=$students[$i];
		echo '<tr>';
  	foreach ($student as $std) {
  		echo '<td>'.$std.'</td>';
  	}
  	echo '</tr>';
	  	
	 	   $i=$i+1; echo '<br>';
	 	 
 	  }	
 	  echo '</table></div> '; 
 
 }


 function studentsain (){
	$nom=$_GET['lname'];
 
 	$students=  DBGet( DBQuery("SELECT lastname,firstname,status,vaccin,doses,datevac,role from covid where lastname like '%$nom%' and role like '%student%' and status like '%sain%'"));

 	  $i=1;

  echo ('<table border="1" width="100%" cellspacing="0" cellpadding="6">
     <h3>Historique Vaccination</h3>
         <tr>
                 <th>lastname</th>
				 <th>firstname</th>
                 <th>status</th>
                 <th>Nom Vaccin</th>
                 <th>Doses</th>
                 <th>date Vaccination</th>
                 <th>role</th>
              </tr>  '); 

      while ($i<=count($students)){
  		$student=$students[$i];
		echo '<tr>';
  	foreach ($student as $std) {
  		echo '<td>'.$std.'</td>';
  	}
  	echo '</tr>';
	  	
	 	   $i=$i+1; echo '<br>';
	 	 
 	  }	
 	  echo '</table> '; 
 
 }

 if (isset($_GET['envoyer'])){
 	student();
 	studentsain();
  	// echo 'envoyer';
 }




// function staff (){
// 	$nom=$_GET['nom'];
 
//  	$staffs=  DBGet( DBQuery("SELECT username,status,sickness,vaccin,doses,role from covid where username like '%$nom%' and role like '%staff%' "));

//  	  $i=1;

//   echo ('<table border="6" width="100%" cellspacing="0" cellpadding="6">
   
//          <tr>
//                  <th>username</th>
//                  <th>status</th>
//                  <th>sickness</th>
//                  <th>vaccin</th>
//                  <th>doses</th>
//                  <th>role</th>
//               </tr>  '); 

//       while ($i<=count($staffs)){
//   		$staff=$staffs[$i];
// 		echo '<tr>';
//   	foreach ($staff as $stf) {
//   		echo '<td>'.$stf.'</td>';
//   	}
//   	echo '</tr>';
// 	 	   $i=$i+1; echo '<br>';
//  	  }	
 // 	  echo '</table> '; 
 // }
echo "<script>
function displaySain(){
	document.getElementById('SainBox').style.display='none';
		document.getElementById('MaladeBox').style.display='block';


}

function displayMalade(){
	document.getElementById('MaladeBox').style.display='none';
	document.getElementById('SainBox').style.display='block';

}
</script>";



/*
                      <legend>Choisir:</legend>
					  <div>
				<input type="search" class="cv" placeholder="Entrer le nom"/>
				 <a href="Modules.php?modname=Covid/historiques.php">
				<button>selectionner </button>
                 </a>

				<script>
				$("input#searchbox").autocomplete({
					source:autocomplete,select:function(event,ui{
						$("input#searchbox").val(ui).item.value);
						$("#searchform").submit();}
					});
				</script>
			*/	

 ?>
 