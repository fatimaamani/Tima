/**
 * Delete SQL
 *
 * Required if install.sql file present
 * - Delete profile exceptions
 * - Delete program config options if any (to every schools)
 * - Delete module specific tables
 * (and their eventual sequences & indexes) if any
 *
 * @package Covid module
 */

--
-- Delete from profile_exceptions table
--

DELETE FROM profile_exceptions WHERE modname='Covid/CovidWidget.php';
DELETE FROM profile_exceptions WHERE modname='Covid/Setup.php';
DELETE FROM profile_exceptions WHERE modname='Covid/Resources.php';
DELETE FROM profile_exceptions WHERE modname='Covid/CovidResource.php';


--
-- Delete options from program_config table
--

DELETE FROM program_config WHERE program='covid';
