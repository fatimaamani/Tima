<?php
/**
 * Module Functions / Actions
 * (Loaded on each page)
 *
 * @package Covid module
 */


/**
 * Covid module Portal Alerts.
 * Covid new note.
 *
 * @uses misc/Portal.php|portal_alerts hook
 *
 * @return true if new messages note, else false.
 */
function CovidPortalAlerts()
{
	global $note;

	if ( ! AllowUse( 'Covid/CovidWidget.php' ) )
	{
		return false;
	}

	// Add note.
	$note[] = '<img src="modules/Covid/icone.jpg" class="button bigger" />
		I am the Covid module note.
		I have been hooked by the "misc/Portal.php|portal_alerts" action and I am registered in my functions.php file.';

	return true;
}


/**
 * Register & Hook our function to
 * the 'misc/Portal.php|portal_alerts' action tag
 * List of available actions:
 * @see functions/Actions.php.
 *
 */
add_action( 'misc/Portal.php|portal_alerts', 'CovidPortalAlerts', 15 );
