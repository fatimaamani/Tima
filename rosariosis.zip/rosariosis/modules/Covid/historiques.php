<?php

    echo('
     <table>
    <thead>
        <tr>
            <th colspan="2">Historiques</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Id Rosarios Name</td>
            <td>First Name</td>
            <td>Last Name</td>
            <td>School Level</td>
            <td>Etat Santé</td>
            <td>Date Maladie</td>
            <td>Type de Vaccin</td>
            <td>Nombre de dose</td>
            

        </tr>
    </tbody>
</table>

 
 
 
 
 ');
 ?>