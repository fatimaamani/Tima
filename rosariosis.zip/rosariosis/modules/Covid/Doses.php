
<?php
$css = '<link href="./test.css" rel="stylesheet"/>';
echo $css
?>

<?php
require_once 'ProgramFunctions/Fields.fnc.php';

$host = "localhost";
$port = "5432";
$dbname = "rosariosis_db";
$user = "";
$password = "matifa";

$connection_string = "host={$host} port={$port} dbname={$dbname} user={$user} password={$password}";
$db = pg_connect($connection_string);



echo ('<div id="body" tabindex="0" role="main" class="mod">
				<table class="header"><tbody><tr class="cv">
                <td class="header1"><h2><span class="module-icon Covid">
                </span>Nombre de Doses</h2></td></tr></tbody>
                </table><br><table class="postbox cellspacing-0"> 	

  <form action="Modules.php?modname=Covid/Doses.php" method="post">

       
<br/>
            <div style="
            text-decoration: none;
            line-height: 14px;
            padding: 6px 10px;
            margin: 0 8px;
            border-width: 1px;
            border-style: solid;
            border-radius: 3px;
            box-sizing: content-box;
            white-space: normal;
            border-color: #15556b;
            font-weight: 700;
            color: #FFFFFF
            background: -moz-linear-gradient(top,#298cba,#1d6385);
            text-shadow: rgba(0,0,0,.3) 0 -1px 0;

            max-width: 100%;
            font-size: 14px;
            word-wrap: break-word;
            text-align: right;
            border-spacing: 0;">

     <div style=" 
            text-align: left;">

        <label for="dose">Saisir:&nbsp;</label>
        <input type="text" id="dose" name="dose" size="24" maxlength="50" autofocus>

	    <input class="button-primary" type="submit"  name="envoyer" value="ajouter" 
        
        style="position:absolute;right:50px;"/>

    </div>
    </div> 

        </form>
    ');

// echo '<form action="Modules.php?modname=Covid/Doses.php" method="post">
// <input type="text" name="nom" placeholder="nom">
// <input  type="submit" id="valider" name="valider" value="valider"/>
// </form>';
//echo $_POST['nom'];


function addDose()
{

    $nbre_doses = $_POST['dose'];

    DBQuery("INSERT INTO doses (nbre_doses) VALUES ('" . $nbre_doses . "')");
}

if (isset($_POST['dose'])) {
    addDose();
}






function afficherTous()
{

    $doses =  DBGet(DBQuery("SELECT id,nbre_doses from doses"));
    $Ids = DBGet(DBQuery("SELECT id from doses"));


    $i = 1;

    echo ('<div><table border="1" width="600px" cellspacing="0" cellpadding="6" class="widefat list rt">
      
                <tr>
                  <th>id</th>
                  <th>nbre doses</th>
                  <th style="text-align:center;">action</th>
                </tr> 
        ');

    while ($i <= count($doses)) {
        $doseD = $doses[$i];
        $IdsD = $Ids[$i];
        $Tab[] = 0;
        $j = $i;
        echo '<tr>';
        foreach ($doseD as $dse) {

            echo '<td>' . $dse . '</td>';
        }
        foreach ($IdsD as $Id) {

            $Tab[$j] = $Id;
            $j = $j + 1;
        }
        $id = $Tab[$i];


        echo '<td> 
       <div><form action="Modules.php?modname=Covid/Doses.php" method="post">
       <div style=" 
       text-align:center;">
       <input type="number" name="idSupprimer"  value="'.$id.'" style="display:none;"/> 
       <input class="button-danger" size="24" maxlength="50" autofocus="" type="submit" name="supprimer" value="supprimer"/>
       </div>
       </form>
       </div>

       </td>';
        echo '</tr>';

        $i = $i + 1;
        echo '<br>';
    }
    echo '</table></div> ';
}



afficherTous();




if (isset($_POST['supprimer'])) {
    DeleteDose();
  
    
}
function DeleteDose()
{
    

    $id = $_POST['idSupprimer'];
    DBQuery("DELETE FROM doses  WHERE id=$id");
}

function nombredose()
{

    $nomD = $_GET['dose'];

    if (isset($_REQUEST['dose']['NBRE_DOSES']))

        $required_error = true;

    $doses =  DBGet(DBQuery("SELECT nbre_doses from dose where nbre_doses like '%$nomD%'"));


    $i = 1;

    echo ('<div><table border="1" width="300px" cellspacing="0" cellpadding="6">
      <h3>Nombre de Doses</h3>
          <tr>
                  <th>1ere dose</th>
                  <th>2eme dose</th>
                  <th>3eme dose</th>
                  <th>4eme dose</th>
               </tr> 
        ');
    while ($i <= count($doses)) {
        $doseD = $doses[$i];
        echo '<tr>';
        foreach ($doseD as $dse) {
            echo '<td>' . $dse . '</td>';
        }
        echo '</tr>';
        $i = $i + 1;
        echo '<br>';
    }
    echo '</table></div> ';
}






?>
