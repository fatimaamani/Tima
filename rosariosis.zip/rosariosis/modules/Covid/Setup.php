<?php





echo( '<div id="body" tabindex="0" role="main" class="mod">
				<table class="header"><tbody><tr class="cv">
                <td class="header1"><h2><span class="module-icon Covid">
                </span>Nom de Vaccin</h2></td></tr></tbody>
                </table><br><table class="postbox cellspacing-0"> ');		

  echo(' <form action="Modules.php?modname=Covid/Setup.php" method="POST">
        <span class="br-after">
        <div style="
        text-decoration: none;
        line-height: 14px;
        padding: 6px 10px;
        margin: 0 8px;
        cursor: pointer;
        border-width: 1px;
        border-style: solid;
        border-radius: 3px;
        box-sizing: content-box;
        white-space: normal;
        border-color: #15556b;
        font-weight: 700;
        color: #FFFFFF
        background: -moz-linear-gradient(top,#298cba,#1d6385);
        text-shadow: rgba(0,0,0,.3) 0 -1px 0;

        max-width: 100%;
        font-size: 14px;
        word-wrap: break-word;
        text-align: right;
        border-spacing: 0;">

            <div style=" 
            text-align: left;">

            <label for="vaccin">Ajouter Nom de vaccin:&nbsp;</label>
            <div>
            <input type="text" id="vaccin" name="vaccin" size="24" maxlength="50" autofocus="">
           </div>
            </div>
        </span>


	<input class="button-primary" type="submit"  name="envoyer" value="ajouter" />
    </div>
     </div>

        </form>
    ');
    function addvaccin(){

        $vaccin=$_POST['vaccin'];
        
        DBQuery( "INSERT INTO vaccination (vaccin) VALUES ('". $vaccin."')");
    
      
       }
    
       if (isset($_POST['vaccin'] )){
        addvaccin();
    
    
    }
    
     
    
      
    
    
    function afficherTous(){
    
         $vaccins=  DBGet( DBQuery("SELECT id,vaccin from vaccination"));
        $Ids= DBGet( DBQuery("SELECT id from vaccination"));
    
    
       $i=1;
    
       echo ('<div><table border="1" width="600px" cellspacing="0" cellpadding="6" class="widefat list rt">
         
              <tr>
                      <th>
                    <div style="
                     :after
                      user-select: none;
                      font-family: Georgia,"Times New Roman",Times,serif;
                      font-size: 16px;
                      text-align: left;
                      border-width: 1px 0;
                      border-style: solid;
                      padding: 3px 7px;
                      vertical-align: top;
                      text-shadow: rgba(255,255,255,.8) 0 1px 0;
                      overflow: hidden;
                      font-weight: 400;
                      line-height: 1.6em;
                      border-top-color: #fff;
                      border-bottom-	
                      7	14 jours	
                      8color: #dfdfdf;
                      background: -moz-linear-gradient(top,#f9f9f9,#ececec);
                      word-wrap: break-word;
                      border-spacing: 0;
                      color: #111;">
                      id
                      </th>
                      </div>
                      
                    
                      <th>Nom de vaccin</th>
                      <th style="text-align:center;">action</th>
                   </tr> 
            '); 
     
           while ($i<=count($vaccins)){
               $vaccinD=$vaccins[$i];
               $IdsD=$Ids[$i];
               $Tab[]=0;
               $j=$i;
             echo '<tr>';
           foreach ($vaccinD as $vac) {
               
               echo '<td>'.$vac.'</td>';
        
           }
           foreach ($IdsD as $Id) {
               
            $Tab[$j]=$Id;
            $j=$j+1;
     
        }
        $id= $Tab[$i];
           
           
           echo '<td> 
                <div><form action="Modules.php?modname=Covid/Setup.php" method="post">
                <div style=" 
       text-align:center;">
                <input type="number" name="idSuprimer" value="'.$id.'" style="display:none;"/> 
                <input class="button-danger" type="submit" name="suprimer" value="supprimer"/>
                </div>
                </form>
                </div>
                </td>';
           echo '</tr>';
               
                 $i=$i+1; echo '<br>';
               
            }	
            echo '</table></div> ';
         }
    
         afficherTous();
         
    
    
         
     if(isset($_POST['idSuprimer'])){
         Deletevaccin();
     }
       function Deletevaccin(){
           $id=$_POST['idSuprimer'];
           DBQuery( "DELETE FROM vaccination  WHERE id=$id");
    
       }


?>
