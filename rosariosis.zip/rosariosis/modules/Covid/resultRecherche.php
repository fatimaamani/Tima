<?php
function student (){
	$nom=$_GET['lname'];
 

	if ((isset($_REQUEST['students']['FIRST_NAME']) && empty($_REQUEST['students']['FIRST_NAME'])) || (isset($_REQUEST['students']['LAST_NAME']) && empty($_REQUEST['students']['LAST_NAME'])))
			$required_error = true;


 	$students=  DBGet( DBQuery("SELECT lastname,firstname,status,sickness,periodeconfinement,datefinconfinement,role from covid where lastname like '%$nom%' and role like '%student%' and status like '%malade%'"));

 	  $i=1;

  echo ('<table border="1" width="100%" cellspacing="0" cellpadding="6">
     <h3>Historique Infection</h3>
         <tr>
                 <th>lastname</th>
				 <th>firstname</th>
                 <th>status</th>
                 <th>sickness</th>
                 <th>periode de confinement</th>
                 <th>date fin confinement</th>
                 <th>role</th>
              </tr>  '); 

      while ($i<=count($students)){
  		$student=$students[$i];
		echo '<tr>';
  	foreach ($student as $std) {
  		echo '<td>'.$std.'</td>';
  	}
  	echo '</tr>';
	  	
	 	   $i=$i+1; echo '<br>';
	 	 
 	  }	
 	  echo '</table> '; 
 
 }


 function studentsain (){
	$nom=$_GET['lname'];
 
 	$students=  DBGet( DBQuery("SELECT lastname,firstname,status,vaccin,doses,datevac,role from covid where lastname like '%$nom%' and role like '%student%' and status like '%sain%'"));

 	  $i=1;

  echo ('<table border="1" width="100%" cellspacing="0" cellpadding="6">
     <h3>Historique Vaccination</h3>
         <tr>
                 <th>lastname</th>
				 <th>firstname</th>
                 <th>status</th>
                 <th>Nom Vaccin</th>
                 <th>Doses</th>
                 <th>date Vaccination</th>
                 <th>role</th>
              </tr>  '); 

      while ($i<=count($students)){
  		$student=$students[$i];
		echo '<tr>';
  	foreach ($student as $std) {
  		echo '<td>'.$std.'</td>';
  	}
  	echo '</tr>';
	  	
	 	   $i=$i+1; echo '<br>';
	 	 
 	  }	
 	  echo '</table> '; 
 
 }

 if (isset($_GET['envoyer'])){
 	student();
 	studentsain();
  	// echo 'envoyer';
 }
?>