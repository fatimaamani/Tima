<?php
/**
 * Menu.php file
 * Required
 * - Menu entries for the Covid module
 * - Add Menu entries to other modules
 *
 * @package Covid module
 * 
 * @uses $menu global var
 *
 * @see  Menu.php in root folder
 *
 * @package RosarioSIS
 * @subpackage modules
 * 

 */

/**
 * Use dgettext() function instead of _() for Module specific strings translation
 * see locale/README file for more information.
 */
$module_name = dgettext( 'Covid', 'Covid' );

// Menu entries for the Covid module.
$menu['Covid']['admin'] = array(
	'title' => _( 'Covid' ),
	'default' => 'Covid/CovidWidget.php',
	1 => _('Suivi'),
	'Covid/CovidWidget.php' => _('Etat Eleve'),
	'Covid/CovidStaff.php' => _('Etat Personnel'),

	2 => _( 'Historiques' ),
	 'Covid/HistoriqueInfectionEleve.php' => _('Historique Infection Eleve'),
	 'Covid/HistoriqueVaccinationEleve.php' => _('Historique Vaccination Eleve'),
	 'Covid/HistoriqueInfectionPersonnel.php' => _('Historique Infection Personnel'),
	 'Covid/HistoriqueVaccinationPersonnel.php' => _('Historique Vaccination Personnel'),

	3 => _('Statistiques'),
	'Covid/StatistiqueGlobal.php' => _('Statistique Globale'),


	4 => _( 'Setup' ), // Add sub-menu 1 (only for admins).
	'Covid/Setup.php' => _('Vaccination'),
	'Covid/PeriodeConfinement.php' => _('Periode Confinement'),
	'Covid/Doses.php' => _('Doses'),
	//'Covid/Vaccination.php' => _( 'Vaccination' ), // Reuse existing translations: 'Configuration' exists under School 
   // 'Covid/Doses.php' => _('Doses'),




	/*2 => _('Suivi'),
	'Covid/nStudentState.php' => _('Etat'),

	3=> _('StaffState'),
	'Covid/StaffState.php' => _( 'Staff State' ),*/
	
	
);

$menu['Covid']['teacher'] = array(
	'title' => _( 'Covid' ),
	'default' => 'Covid/CovidWidget.php',
	'Covid/CovidWidget.php' => _( 'Covid Info' ),
);

$menu['Covid']['parent'] = $menu['Covid']['teacher']; // Parent & student menu.

// Add a Menu entry to the Resources module.
if ( $RosarioModules['Resources'] ) // Verify Resources module is activated.
{
	$menu['Resources']['admin'] += [
		1 => dgettext( 'Covid', 'Covid' ), // Add sub-menu 1.
		'Covid/CovidResource.php' => dgettext( 'Covid', 'Covid Resource' ),
	];
}
