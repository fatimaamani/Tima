<?php





echo( '<div id="body" tabindex="0" role="main" class="mod">
				<table class="header"><tbody><tr class="cv">
                <td class="header1"><h2><span class="module-icon Covid">
                </span>Historique Infection Personnels</h2></td></tr></tbody>
                </table><br><table class="postbox cellspacing-0"> ');		

  echo(' <form action="Modules.php?modname=Covid/HistoriqueInfectionPersonnels.php" method="POST">

  <a href="Modules.php?modname=Covid/HistoriqueInfectionPersonnels.php" style="" id="selectedMenuLink">Année Scolaire</a>


  <select name="values[new][SYEAR]" id="valuesnewSYEAR">
        <option value="2013">2013-2014</option>
        <option value="2014">2014-2015</option>
        <option value="2015">2015-2016</option>
        <option value="2016">2016-2017</option>
        <option value="2017">2017-2018</option>
		<option value="2018">2018-2019</option>
        <option value="2019">2019-2020</option>
        <option value="2020">2020-2021</option>
        <option value="2021">2021-2022</option>
		<option value="2022">2022-2023</option>
        <option value="2023">2023-2024</option>
        <option value="2024">2024-2025</option>s
        <option value="2025">2025-2026</option>
		<option value="2026">2026-2027</option>
        <option value="2027">2027-2028</option>
		<option value="2028">2028-2029</option>
		<option value="2029">2029-2030</option>
        <option value="2030">2030-2031</option>





    </select>
        </form>
    ');
    $staffs=  DBGet( DBQuery("SELECT lastname,firstname,status,sickness,periodeconfinement,datefinconfinement,role from covid where role like '%staff%' and status like '%malade%'"));

      $i=1;

  echo ('<table border="1" width="100%" cellspacing="0" cellpadding="6" class="widefat rt list">
     <h3>Historique Infection</h3>
         <tr>
                 <th>lastname</th>
                 <th>firstname</th>
                 <th>status</th>
                 <th>sickness</th>
                 <th>periode de confinement</th>
                 <th>date fin confinement</th>
                 <th>role</th>
              </tr>  '); 

      while ($i<=count($staffs)){
        $staff=$staffs[$i];
        echo '<tr>';
    foreach ($staff as $staf) {
        echo '<td>'.$staf.'</td>';
    }
    echo '</tr>';
        
           $i=$i+1; echo '<br>';
         
      } 
      echo '</table> '; 

?>
