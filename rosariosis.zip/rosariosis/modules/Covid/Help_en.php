<?php
/**
 * English Help texts
 *
 * Texts are organized by:
 * - Module
 * - Profile
 *
 * Please use this file as a model to translate the texts to your language
 * The new resulting Help file should be named after the following convention:
 * Help_[two letters language code].php
 *
 * @author François Jacquet
 *
 * @package Covid module
 * @subpackage Help
 */

// EXAMPLE ---.
if ( User( 'PROFILE' ) === 'admin' ) :

	$help['Covid/CovidResource.php'] = '<p>' . _help( '<i>Covid Resource</i> lets you consult an covid <b>resource</b>.', 'Covid' ) . '</p>
	<p>' . _help( 'I am the inline help for the <code>CovidResource.php</code> program, you will find me in the <code>Help_en.php</code> file, see you!', 'Covid' ) . '</p>';

	$help['Covid/CovidWidget.php'] = '<p>' . _help( '<i>Covid Widget</i> lets you use an covid <b>widget</b>.', 'Covid' ) . '</p>
	<p>' . _help( 'I am the inline help for the <code>CovidWidget.php</code> program, you will find me in the <code>Help_en.php</code> file, see you!', 'Covid' ) . '</p>';

	$help['Covid/Setup.php'] = '<p>' . _help( '<i>Setup</i> lets you <b>configure</b> the module.', 'Covid' ) . '</p>
	<p>' . _help( 'I am the inline help for the <code>Setup.php</code> program, you will find me in the <code>Help_en.php</code> file, see you!', 'Covid' ) . '</p>';

endif;


// Teacher help.
if ( User( 'PROFILE' ) === 'teacher' ) :

	$help['Covid/CovidWidget.php'] = '<p>' . _help( '<i>Covid Widget</i> lets you use an covid <b>widget</b>.', 'Covid' ) . '</p>
	<p>' . _help( 'I am the inline help for the <code>CovidWidget.php</code> program, you will find me in the <code>Help_en.php</code> file, see you!', 'Covid' ) . '</p>
	<p>' . _help( 'This text should be readable by <b>teachers</b> only!', 'Covid' ) . '</p>';

endif;


// Parent & student help.
if ( User( 'PROFILE' ) === 'parent' ) :

	$help['Covid/CovidWidget.php'] = '<p>' . _help( '<i>Covid Widget</i> lets you use an covid <b>widget</b>.', 'Covid' ) . '</p>
	<p>' . _help( 'I am the inline help for the <code>CovidWidget.php</code> program, you will find me in the <code>Help_en.php</code> file, see you!', 'Covid' ) . '</p>
	<p>' . _help( 'This text should be readable by <b>parents or students</b> only!', 'Covid' ) . '</p>';

endif;
