
<?php





echo( '<div id="body" tabindex="0" role="main" class="mod">
				<table class="header"><tbody><tr class="cv">
                <td class="header1"><h2><span class="module-icon Covid">
                </span>Nom de Vaccin</h2></td></tr></tbody>
                </table><br><table class="postbox cellspacing-0"> ');		

  echo(' <form action="Modules.php?modname=Covid/Vaccination.php" method="POST">
        <span class="br-after">
            <label for="vaccin">Ajouter Nom de vaccin:&nbsp;</label>
               <select name = "vaccin">
                  <option value="Pfizer BioNTech" selected> Pfizer BioNTech </option>
                  <option value="Moderna" selected>Moderna</option>
                  <option value="AstraZeneca" selected>AstraZeneca </option>
                  <option value="Johnson & Johnson" selected>Johnson & Johnson</option>
                  <option value="Spoutnik V" selected>Spoutnik V</option>
                  <option value="Sinovac" selected>Sinovac</option>

            </select>
        </span>
        </form>
    ');
    function addvaccin(){

        $vaccin=$_POST['vaccin'];
        
        DBQuery( "INSERT INTO vaccination (vaccin) VALUES ('". $vaccin."')");
    
      
       }
    
       if (isset($_POST['vaccin'] )){
        addvaccin();
    
    
    }
    
     
    
      
    
    
    function afficherTous(){
    
         $vaccins=  DBGet( DBQuery("SELECT id,vaccin from vaccination"));
        $Ids= DBGet( DBQuery("SELECT id from vaccination"));
    
    
       $i=1;
    
       echo ('<div><table border="1" width="600px" cellspacing="0" cellpadding="6" class="widefat list rt">
          <h3>Nombre de vaccins</h3>
              <tr>
                      <th>id</th>
                      <th>Nom de vaccin</th>
                      <th>action</th>
                   </tr> 
            '); 
     
           while ($i<=count($vaccins)){
               $vaccinD=$vaccins[$i];
               $IdsD=$Ids[$i];
               $Tab[]=0;
               $j=$i;
             echo '<tr>';
           foreach ($vaccinD as $vac) {
               
               echo '<td>'.$vac.'</td>';
        
           }
           foreach ($IdsD as $Id) {
               
            $Tab[$j]=$Id;
            $j=$j+1;
     
        }
        $id= $Tab[$i];
           
           
           echo '<td> 
           <div><form action="Modules.php?modname=Covid/Vaccination.php" method="post">
           <input type="number" name="idSuprimer" value="'.$id.'" style="display:none;"/> 
           <input class="button-danger" type="submit" name="suprimer" value="suprimer"/>
           </form>
           </div>
           <div>
           <form style="float:left;" action="Modules.php?modname=Covid/Vaccination.php" method="post">
           <input type="number" name="idModifier" style="display:none;"/> 
           <input class="button-primary" type="submit" name="modifier" value="modifier"/>
           </div></form>
           </td>';
           echo '</tr>';
               
                 $i=$i+1; echo '<br>';
               
            }	
            echo '</table></div> ';
         }
    
         afficherTous();
         
    
    
         
     if(isset($_POST['idSuprimer'])){
         Deletevaccin();
        
     }
       function Deletevaccin(){
           $id=$_POST['idSuprimer'];
           DBQuery( "DELETE FROM vaccins  WHERE id=$id");
    
       }


?>
