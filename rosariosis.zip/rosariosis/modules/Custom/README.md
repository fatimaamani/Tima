# Custom Module

This module is part of [RosarioSIS](https://www.rosariosis.org)

Author François Jacquet
See COPYRIGHT file.

## Description

This module adds 5 utilities to other modules of RosarioSIS.

## Content

Students

- My Report
- Create Parent Users (created from the students' contacts)
- Registration (for parents & students to register their contacts)

Users

- Notify Parents (who never logged into RosarioSIS)

Attendance

- Attendance Summary
